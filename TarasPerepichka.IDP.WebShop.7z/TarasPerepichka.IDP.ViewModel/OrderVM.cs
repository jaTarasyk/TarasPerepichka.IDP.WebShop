﻿namespace TarasPerepichka.IDP.ViewModel
{
    public class OrderVM
    {
        public int Id { get; set; }
        public int Quantity { get; set; }
        public ArticleVM Article { get; set; }
    }
}
